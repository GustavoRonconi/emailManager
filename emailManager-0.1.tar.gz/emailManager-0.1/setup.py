from setuptools import setup, find_packages

setup(name = 'emailManager',
      version = "0.1",
      install_requires = [],
      packages = find_packages(),
      zip_safe=False)